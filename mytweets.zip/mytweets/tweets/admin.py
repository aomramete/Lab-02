from django.contrib import admin
from tweets.models import Tweet
admin.site.register(Tweet)
